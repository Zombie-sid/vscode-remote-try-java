package com.documnet.documentCheck.Service;

import java.io.IOException;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.documnet.documentCheck.Payload.UploadDto;


public interface UploadService  {
	
	public String uploadData(MultipartFile file,Integer numberOfSheet) throws IOException;
	
	UploadDto getPostById(long id);
}
