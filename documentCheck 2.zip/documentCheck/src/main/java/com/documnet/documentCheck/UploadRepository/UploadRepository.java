package com.documnet.documentCheck.UploadRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.documnet.documentCheck.Entity.Upload;

public interface UploadRepository extends JpaRepository<Upload,Long>{

	
	
	
	
}
