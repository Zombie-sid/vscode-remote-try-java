package com.documnet.documentCheck.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.documnet.documentCheck.Payload.UploadDto;
import com.documnet.documentCheck.Service.UploadService;

@RestController
@RequestMapping("/api")
public class UploadController {
	
	private UploadService uploadService;
    
	@Autowired
	public UploadController(UploadService uploadService) {
		super();
		this.uploadService = uploadService;
	}
	
	
	
	@PostMapping("/upload")
    public String upload(
            @RequestParam MultipartFile file,
            @RequestParam Integer numberOfSheet)
            throws Exception {
        return uploadService.uploadData(file, numberOfSheet);
    }
	
	 @GetMapping("/{id}")
	    public ResponseEntity<UploadDto> getPostById(@PathVariable("id") long id)
	    {
	        return new ResponseEntity<>(uploadService.getPostById(id),HttpStatus.OK);
	    }
}