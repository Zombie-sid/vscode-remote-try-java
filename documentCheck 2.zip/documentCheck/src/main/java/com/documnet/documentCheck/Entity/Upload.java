package com.documnet.documentCheck.Entity;



import java.util.List;

import com.documnet.documentCheck.Service.impl.UploadServiceImpl;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor

@Entity
@EntityListeners(UploadServiceImpl.class)
@Table(
        name = "Upload" 
)
public class Upload {

	
	

	
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Id
    //If we don't specify column name then JPA will understand it has a column name
    private long id;
	
	@Override
	public String toString() {
		return "Upload [id=" + id + ", name=" + name + "]";
	}

	@Column (name = "name",nullable = false)
	private String name;
}
