package com.documnet.documentCheck.Service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.documnet.documentCheck.Entity.Upload;
import com.documnet.documentCheck.Payload.UploadDto;
import com.documnet.documentCheck.Service.UploadService;
import com.documnet.documentCheck.UploadRepository.UploadRepository;

import ch.qos.logback.core.net.SyslogOutputStream;

@Service
public class UploadServiceImpl implements UploadService {

	private  UploadRepository uploadRepository;
	public UploadServiceImpl(UploadRepository uploadRepository) {
		
		this.uploadRepository = uploadRepository;
	}
	
	
	@Override
	public String uploadData(MultipartFile file, Integer numberOfSheet) throws IOException {
		// TODO Auto-generated method stub
		
		System.out.println(numberOfSheet);
		HSSFWorkbook workbook = new HSSFWorkbook(file.getInputStream());
		HSSFSheet sheet1 = workbook.getSheetAt(0);
		
		int rowCount = sheet1.getLastRowNum();
 		//Check the sheet number 
		 if (numberOfSheet == null || numberOfSheet < 0) {
	            numberOfSheet = workbook.getNumberOfSheets();
	        }
		 
		 String cellValue;
         List<String> contain = new ArrayList();
    	 for (int i = 0; i < numberOfSheet; i++) {
	            // Getting the Sheet at index i
	            HSSFSheet sheet = workbook.getSheetAt(i);
	            System.out.println("=> " + ((HSSFSheet) sheet).getSheetName());
	            // Create a DataFormatter to format and get each cell's value as String
	            DataFormatter dataFormatter = new DataFormatter();
	            // 1. You can obtain a rowIterator and columnIterator and iterate over them
	            System.out.println("Iterating over Rows and Columns using Iterator \n");
	            //iterate over the row and cell
	            Iterator<Row> rowIterator = ((HSSFSheet) sheet).rowIterator();
	            while (rowIterator.hasNext()) 
	            {
	                Row row = rowIterator.next();
	              
	                // Now let's iterate over the columns of the current row
	                Iterator<Cell> cellIterator = row.cellIterator();
	                while (cellIterator.hasNext()) {
	                    Cell cell = cellIterator.next();
	                    cellValue = dataFormatter.formatCellValue(cell);
	                    contain.add(cellValue);
	                    System.out.print(cellValue + "\t");
	                }
	                System.out.println();
	            }
	        }
		
 		
		 List<Upload> upload = createList(contain, rowCount);
	     uploadRepository.saveAll(upload);
		 
		return "Successfully Working";
	}

	private List<Upload> createList(List<String> contain, int rowCount) {
		 ArrayList<Upload> upload = new ArrayList<Upload>();

	 		int i = rowCount;
	 		do {
	 			Upload upload1 = new Upload();
	 			long hills = Long.parseLong(contain.get(i));
	 			System.out.println("id"+hills);
	 			upload1.setId(hills);
	 			upload1.setName(contain.get(i+1));
	 			System.out.println("name"+contain.get(i+1));
	 			i = i + (rowCount);
	 			
	 			upload.add(upload1);

	 		} while (i < contain.size());
		return upload;
	}


	@Override
	public UploadDto getPostById(long id) {
		

	        Upload upload = uploadRepository.findById(id).orElseThrow();
	        return maptoDto(upload);
	}
	private UploadDto maptoDto(Upload upload)
    {
		UploadDto uploadDto = new UploadDto();
		uploadDto.setId(upload.getId());
		uploadDto.setName(upload.getName());
        return uploadDto;

    }






	

}
