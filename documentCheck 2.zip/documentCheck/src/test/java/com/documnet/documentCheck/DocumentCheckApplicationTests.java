package com.documnet.documentCheck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocumentCheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
